let stu = {name: "Kushal", age: 18};
let details = {city: "Hyderabad", country: "India"};

let fullDetails = {...stu, ...details};

console.log(fullDetails); // Output: {name: "Kushal", age: 18, city: "Hyderabad", country: "India"}