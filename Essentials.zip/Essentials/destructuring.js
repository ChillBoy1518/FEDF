//Array Destructuring
let numbers = [3, 15, 8, 1503];

let [first, second, ...rest] = numbers;

console.log("First: ", first);
console.log("Second: ", second);
console.log("Rest: ", rest);

//Object Destructuring
let student = {
    name: "Kushal",
    age: 18,
    city: "Visakhapatnam"
};

//basic + default value + renaming + rest operator
let {
    name: studentName,   // renaming variable
    age,
    country = "India",   //default value
    ...otherDetails      //rest operator to collect remaining properties
} = student;

console.log("Student Name: ", studentName);
console.log("Age: ", age);
console.log("Country: ", country);
console.log("Other Details: ", otherDetails);

//function destricturing
function display({name, age}) {
    console.log(`Name: ${name}, Age: ${age}`);
}

display(student);