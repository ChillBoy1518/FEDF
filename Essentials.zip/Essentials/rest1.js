display(1, 2, 3, 4, 5);

function display(first, second, ...restArguments) {
    console.log("First:", first);
    console.log("Second:", second);

    console.log("Rest:", restArguments);
}