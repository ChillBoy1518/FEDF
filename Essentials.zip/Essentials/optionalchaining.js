let user = {
    profile: {
        name: "Kushal",
        age: 18,
        address: {
            city: "Hyderabad",
            country: "India"
        }
    },

    hobbies: ["Coding", "music", "Cooking"],

    greet() {
        return "Hello!";
    }
}   

console.log(user.profile.name); // Output: Kushal
console.log(user.profile.address.city);