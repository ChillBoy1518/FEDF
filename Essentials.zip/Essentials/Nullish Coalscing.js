let name = null;
let username = "";
let marks = 0;
let city;

//Using ??
console.log("-----Using??-----");
console.log("Name:", name??"Kushal");
console.log("Username:", username??"Kushal");
console.log("Marks:", marks??100);
console.log("City:", city??"Hyderabad");

//Using ||
console.log("-----Using||-----");
console.log("Name:", name||"Kushal");
console.log("Username:", username||"Kushal");
console.log("Marks:", marks||100);
console.log("City:", city||"Hyderabad");
