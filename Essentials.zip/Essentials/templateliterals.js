let name = "Kushal";
let age = 18;

//Using template literals
let message = `Hello, I am ${name}! My age is ${age} years old.`;

console.log(message);

//Multi-line String
let text = `This is line 1
This is line 2
This is line 3`;
console.log(text);

//Expression inside template literals
let a = 5;
let b = 10;
console.log(`The sum of ${a} and ${b} is ${a + b}.`);