//Normal function

function add(a, b) {
    return a + b;
}

//Arrow function (short form)
const addArrow = (a, b) => a + b;

console.log("Normal: ", add(2, 3));
console.log("Arrow: ", addArrow(2, 3));

//Arrow function with one parameter

