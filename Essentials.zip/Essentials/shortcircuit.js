let isLoggedIn = true;
let title = "";

//using && -> runs only if the first condition is true
isLoggedIn && console.log("User is logged in!");

//another example
isLoggedIn && console.log(title = "Welcome to the dashboard!");