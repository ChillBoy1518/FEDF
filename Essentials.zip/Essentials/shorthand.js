let name = "kushal";
let age = 18;
let city = "Hyderabad";

//object short hand
let user = {
    name,
    age,
    city
}
console.log(user);